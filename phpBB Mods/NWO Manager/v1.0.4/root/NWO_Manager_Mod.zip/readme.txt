To install:

Copy all files over to root of forum
Login to ACP
Point to /install_nwomanager.php
Follow instructions
If all goes well, it should install 3 acp modules under .MODs tab
You should probably purge cache after installing anyhow.
